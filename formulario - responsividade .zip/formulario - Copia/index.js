import React from "react";
import "../formulario/forms.css"

export const Forms = () => {
  return (
    <div>
      <header>
        <nav className="navbar navbar-forms fixed-top">
          <div className="container-fluid">
            <a className="navbar-brand navbar-brand-forms" href="#">Alpha</a>
            <button className="navbar-toggler d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
          </div>

          {/* Offcanvas */}
          <div className="offcanvas offcanvas-end" tabIndex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div className="offcanvas-header">
              <button type="button" className="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div className="offcanvas-body">
              <ul className="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li className="nav-item">
                  <a className="nav-link active" aria-current="page" href="#">
                    Deshboard
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Alerta
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Visualizar
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Listar
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Cadastrar
                  </a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Perfil
                  </a>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Logout</a></li>
                    <li><a class="dropdown-item" href="#">Meu perfil</a></li>

                  </ul>
                </li>

              </ul>
            </div>
          </div>

        </nav>
      </header>

      <body>

{/*       
        <div className="content-forms">
          <div className="info-header-forms">
            <h1>Cadastrar</h1>
            <button type="button" class="btn btn-cadastrar ">CADASTRAR</button>
          </div>


        </div> */}

<div className="content-layout-forms">
                        <h2>  Cadastrar</h2>
                        <img src="../img/img_centro.svg" alt="" />
                        <button type="button" class="btn btn-cadastrar ">CADASTRAR</button>
                     

                    
                    </div>


        {/* </div>
                </div> */}

        <div class="container">
          <form className="tudo">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="nome">Nome</label>
                  <input type="text" class="form-control" id="nome" placeholder="Digite seu nome" />
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" id="email" placeholder="Digite seu email" />
                </div>
                <div class="form-group">
                  <label for="senha">Senha</label>
                  <input type="password" class="form-control" id="senha" placeholder="Digite sua senha" />
                </div>
                <div class="form-group">
                  <label for="cpf">CPF</label>
                  <input type="text" class="form-control" id="cpf" placeholder="Digite seu CPF" />
                </div>
              </div>
              <div class="col-md-6">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="cep">CEP</label>
                      <input type="text" class="form-control" id="cep" placeholder="Digite seu CEP" />
                    </div>
                  </div>
                </div>
                <div class="row city">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="cidade">Cidade</label>
                      <input type="text" class="form-control" id="cidade" placeholder="Digite sua cidade" />
                    </div>
                  </div>
                  <div class="col-md-6 state">
                    <div class="form-group">
                      <label for="estado">Estado</label>
                      <input type="text" class="form-control" id="estado" placeholder="Digite seu estado" />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="endereco">Endereço</label>
                      <input type="text" class="form-control" id="endereco" placeholder="Digite seu endereço" />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="complemento">Complemento</label>
                      <input type="text" class="form-control" id="complemento" placeholder="Digite o complemento" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <div className="btn-cadastrar-mobile-footer ">
          <button type="button" class="btn btn-cadastrar-m">CADASTRAR</button>
        </div>
        </div>
        

        <footer className="fixed-bottom">

          <nav className="navbar navbar-expand-md bottom-navbar">
            <button className="navbar-toggler close-btn" type="button" data-toggle="collapse" data-target="#bottomNavbar">
              <span>&times;</span>
            </button>
            <div className="collapse navbar-collapse" id="bottomNavbar">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconDeshboard.svg" alt="Imagem" /></a>
                  </div>
                </li>
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconAlert.svg" alt="Imagem" /></a>
                  </div>
                </li>
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconView.svg" alt="Imagem" /></a>
                  </div>
                </li>
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconList.svg" alt="Imagem" /></a>
                  </div>
                </li>
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconEdit.svg" alt="Imagem" /></a>
                  </div>
                </li>

                <a className="button-close"><p>X</p></a>

              </ul>
            </div>
          </nav>
        </footer>

      </body>
    </div>


  )
}

export default Forms;

